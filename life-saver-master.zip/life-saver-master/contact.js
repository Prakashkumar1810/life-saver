document.getElementById('img').addEventListener('click',function(){
	document.querySelector('.infod').style.display= 'flex';
});
document.querySelector('.close').addEventListener('click',function(){
	document.querySelector('.infod').style.display= 'none';
})
document.getElementById('img1').addEventListener('click',function(){
	document.querySelector('.infop').style.display= 'flex';
});
document.querySelector('.close1').addEventListener('click',function(){
	document.querySelector('.infop').style.display= 'none';
})